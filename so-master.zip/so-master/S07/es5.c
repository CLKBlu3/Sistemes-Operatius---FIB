main(){

while(1);

}
